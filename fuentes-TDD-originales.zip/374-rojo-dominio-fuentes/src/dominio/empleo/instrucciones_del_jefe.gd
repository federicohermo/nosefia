class_name InstruccionesDelJefe
extends RefCounted


class Paso:
	extends RefCounted

	var foto: Mensaje
	var texto: Mensaje


func _init(_cantidad: int) -> void:
	pass


static func pasos_de(_mensajes: Array[Mensaje]) -> Array[Paso]:
	return []


func a_la_vista() -> int:
	return 1


func avanzar() -> void:
	pass


func volver() -> bool:
	return false


func se_puede_volver() -> bool:
	return false


func en_el_ultimo() -> bool:
	return false


func terminadas() -> bool:
	return false
